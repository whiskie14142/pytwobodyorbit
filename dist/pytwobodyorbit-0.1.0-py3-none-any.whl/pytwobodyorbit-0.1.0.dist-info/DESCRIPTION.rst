Python module for computations about Kepler orbit.


